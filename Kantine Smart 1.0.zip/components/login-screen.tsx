'use client';

import { ArrowRight, ChefHat, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck, Sparkles } from 'lucide-react';
import { FormEvent, useState } from 'react';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) {
        setError(result.error || 'Não foi possível abrir o painel agora. Tente novamente.');
        setLoading(false);
        return;
      }
      window.setTimeout(() => {
        window.localStorage.setItem('kantine-authenticated', 'true');
        const next = new URLSearchParams(window.location.search).get('next');
        window.location.replace(next?.startsWith('/') ? next : '/');
      }, 550);
    } catch {
      setError('Não foi possível conectar ao painel. Verifique o servidor e tente novamente.');
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#F7F3F0] text-ink lg:grid lg:grid-cols-[0.95fr_1.05fr]">
      <section className="relative hidden overflow-hidden bg-[#39161B] px-14 py-12 text-[#F7F3F0] lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-28 h-80 w-80 rounded-full border border-white/10" />
        <div className="absolute -bottom-40 -left-20 h-[28rem] w-[28rem] rounded-full border border-[#D59FA0]/20" />
        <div className="relative flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-[14px] bg-[#E3B4B4] text-[#39161B]"><ChefHat size={22} strokeWidth={2.4} /></div>
          <span className="font-display text-[25px] tracking-tight">Kantine Smart</span>
        </div>
        <div className="relative max-w-[510px] pb-8">
          <p className="mb-6 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.24em] text-[#E3B3B0]"><Sparkles size={14} /> Operação com clareza</p>
          <h1 className="font-display text-[58px] leading-[0.98] tracking-[-0.04em]">A cozinha certa começa antes do serviço.</h1>
          <p className="mt-7 max-w-[420px] text-[15px] leading-7 text-white/65">Cardápio, estoque e metas conversando em uma única tela para você cozinhar com mais previsibilidade e menos desperdício.</p>
          <div className="mt-10 flex gap-3 text-xs text-white/70">
            <span className="rounded-full border border-white/15 px-3 py-2">Estoque em tempo real</span>
            <span className="rounded-full border border-white/15 px-3 py-2">Agenda semanal</span>
          </div>
        </div>
        <p className="relative text-xs text-white/35">Feito para cozinhas que querem servir bem.</p>
      </section>

      <section className="flex min-h-screen items-center justify-center px-6 py-12 sm:px-12">
        <div className="w-full max-w-[430px]">
          <div className="mb-12 flex items-center gap-3 lg:hidden"><div className="flex h-10 w-10 items-center justify-center rounded-[13px] bg-[#F0D8D5] text-basil"><ChefHat size={20} /></div><span className="font-display text-2xl">Kantine Smart</span></div>
          <div className="mb-9">
            <p className="mb-4 text-[11px] font-bold uppercase tracking-[0.24em] text-basil">Painel de gestão</p>
            <h2 className="font-display text-[42px] leading-none tracking-[-0.03em] text-ink">Bom ter você de volta.</h2>
            <p className="mt-4 text-sm leading-6 text-[#7C6C6E]">Entre para continuar organizando o serviço de hoje.</p>
          </div>
          <form onSubmit={handleSubmit} autoComplete="off" className="space-y-5">
            <label className="block"><span className="mb-2 block text-xs font-bold text-[#5C4548]">E-mail profissional</span><div className="relative"><Mail className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#A89494]" size={17} /><input autoComplete="off" value={email} onChange={(event) => setEmail(event.target.value)} className="h-13 w-full rounded-2xl border border-[#E8DAD8] bg-white pl-11 pr-4 text-sm text-ink outline-none transition focus:border-basil focus:ring-4 focus:ring-[#B32134]/10" type="email" required /></div></label>
            <label className="block"><div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold text-[#5C4548]">Senha</span><button type="button" className="text-[11px] font-semibold text-basil">Esqueci minha senha</button></div><div className="relative"><LockKeyhole className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[#A89494]" size={17} /><input autoComplete="off" value={password} onChange={(event) => setPassword(event.target.value)} className="h-13 w-full rounded-2xl border border-[#E8DAD8] bg-white pl-11 pr-12 text-sm text-ink outline-none transition focus:border-basil focus:ring-4 focus:ring-[#B32134]/10" type={showPassword ? 'text' : 'password'} required /><button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#A89494]" aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div></label>
            <button disabled={loading} className="group flex h-13 w-full items-center justify-center gap-2 rounded-2xl bg-[#B32134] text-sm font-bold text-white shadow-[0_10px_22px_rgba(179,33,52,.20)] transition hover:bg-[#8F1E2C] disabled:opacity-60">{loading ? 'Abrindo painel…' : 'Entrar no painel'} {!loading && <ArrowRight size={17} className="transition group-hover:translate-x-1" />}</button>
          </form>
          {error && <p className="mt-3 rounded-xl bg-[#F8E6E3] px-3 py-2.5 text-center text-[11px] font-semibold text-[#97443F]">{error}</p>}
          <div className="mt-7 flex gap-3 rounded-2xl border border-[#ECD7D4] bg-[#F7ECE9] p-4"><ShieldCheck className="mt-0.5 shrink-0 text-basil" size={17} /><div><p className="text-xs font-bold text-[#6F252E]">Acesso de demonstração</p><p className="mt-1 text-[11px] leading-5 text-[#8C6E70]">admin@kantine.test <span className="px-1 text-[#D1BBBA]">•</span> credencial fictícia para testes</p></div></div>
          <p className="mt-9 text-center text-[11px] text-[#A89494]">Kantine Smart v1.0 <span className="px-2">·</span> Ambiente seguro</p>
        </div>
      </section>
    </main>
  );
}
