import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        ink: '#39161B',
        basil: '#B32134',
        sage: '#F0D7D4',
        cream: '#F7F3F0',
        coral: '#BA5A4F',
        sand: '#E9DBD7',
        tomato: '#D94A3D',
        paprika: '#C66A3D',
        saffron: '#D39A32',
        'food-cream': '#FFF7EC',
      },
      fontFamily: {
        sans: ['var(--font-manrope)', 'ui-sans-serif', 'system-ui'],
        display: ['var(--font-dm-serif)', 'Georgia', 'serif'],
      },
      boxShadow: {
        soft: '0 12px 40px rgba(37, 55, 46, 0.08)',
        lift: '0 16px 36px rgba(37, 55, 46, 0.13)',
      },
      animation: {
        'fade-up': 'fade-up 0.5s ease-out both',
        'pulse-soft': 'pulse-soft 2.4s ease-in-out infinite',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-soft': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.55' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
