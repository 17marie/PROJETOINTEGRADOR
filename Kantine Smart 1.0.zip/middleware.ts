import { NextRequest, NextResponse } from 'next/server';

const SESSION_COOKIE = 'webdev_app_session';
const SESSION_SECRET = process.env.AUTH_SECRET || 'nourish-local-session-secret';

function decodeBase64Url(value: string) {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (value.length % 4)) % 4);
  const binary = atob(normalized);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

async function hasValidSession(token: string | undefined) {
  if (!token) return false;
  const [payload, digest] = token.split('.');
  if (!payload || !digest) return false;
  try {
    const key = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(SESSION_SECRET),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify'],
    );
    const validSignature = await crypto.subtle.verify('HMAC', key, decodeBase64Url(digest), new TextEncoder().encode(payload));
    if (!validSignature) return false;
    const session = JSON.parse(new TextDecoder().decode(decodeBase64Url(payload))) as { exp?: number };
    return typeof session.exp === 'number' && session.exp > Date.now();
  } catch {
    return false;
  }
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isLogin = pathname === '/login';
  const isPublicApi = pathname === '/api/auth/login' || pathname === '/api/health';
  const isAsset = pathname.startsWith('/_next/') || pathname === '/favicon.ico' || pathname === '/manus-routes.json' || pathname.startsWith('/menu/');

  if (isLogin || isPublicApi || isAsset) return NextResponse.next();
  if (await hasValidSession(request.cookies.get(SESSION_COOKIE)?.value)) return NextResponse.next();

  if (pathname.startsWith('/api/')) {
    return NextResponse.json({ error: 'Autenticação necessária.' }, { status: 401 });
  }

  const loginUrl = new URL('/login', request.url);
  loginUrl.searchParams.set('next', pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  matcher: ['/((?!.*\\.).*)'],
};
