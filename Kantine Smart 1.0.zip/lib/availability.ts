export type AvailabilityIngredient = {
  ingredient: { id: string; name: string; currentStock: number; unit: string };
  quantityRequired: number;
};

export function calculateAvailability(ingredients: AvailabilityIngredient[]) {
  if (!ingredients.length) return { portions: 0, isAvailable: false, bottleneck: null };
  const capacities = ingredients.map((item) => ({
    ingredient: item.ingredient,
    portions: Math.floor(item.ingredient.currentStock / item.quantityRequired),
    quantityRequired: item.quantityRequired,
  }));
  const bottleneck = capacities.reduce((lowest, current) => current.portions < lowest.portions ? current : lowest);
  return { portions: bottleneck.portions, isAvailable: bottleneck.portions > 0, bottleneck };
}

export function calculateDishStatus(dish: { dishIngredients: AvailabilityIngredient[] }) {
  return calculateAvailability(dish.dishIngredients);
}
