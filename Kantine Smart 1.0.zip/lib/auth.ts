import { cookies } from 'next/headers';
import { createHmac, timingSafeEqual } from 'crypto';

export const SESSION_COOKIE = 'webdev_app_session';
const SESSION_SECRET = process.env.AUTH_SECRET || 'nourish-local-session-secret';

type SessionUser = { id: string; name: string; email: string; role: string };

function signature(payload: string) {
  return createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
}

export function createSessionToken(user: SessionUser) {
  const payload = Buffer.from(JSON.stringify({ ...user, exp: Date.now() + 1000 * 60 * 60 * 24 * 30 })).toString('base64url');
  return `${payload}.${signature(payload)}`;
}

export function verifySessionToken(token: string): SessionUser | null {
  const [payload, digest] = token.split('.');
  if (!payload || !digest) return null;
  const expected = signature(payload);
  if (digest.length !== expected.length || !timingSafeEqual(Buffer.from(digest), Buffer.from(expected))) return null;
  try {
    const user = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as SessionUser & { exp?: number };
    return user.exp && user.exp > Date.now() ? user : null;
  } catch {
    return null;
  }
}

export function getSessionUser() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  return token ? verifySessionToken(token) : null;
}
