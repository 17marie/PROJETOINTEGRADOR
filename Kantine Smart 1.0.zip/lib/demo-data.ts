export type Ingredient = {
  id: string;
  name: string;
  unit: string;
  stock: number;
  min: number;
  trend: number;
  category: string;
};

export type DishIngredient = { ingredientId: string; quantity: number };

export type Dish = {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  ingredients: DishIngredient[];
  accent: string;
};

export type MenuDay = {
  id?: string;
  key: string;
  label: string;
  date: string;
  iso: string;
  target: number;
  revenue: number;
  note: string;
  special: string;
  dishIds: string[];
};

export const initialIngredients: Ingredient[] = [
  { id: 'chicken', name: 'Peito de frango', unit: 'kg', stock: 18.5, min: 8, trend: 12, category: 'Proteína' },
  { id: 'rice', name: 'Arroz agulhinha', unit: 'kg', stock: 24, min: 12, trend: 4, category: 'Secos' },
  { id: 'tomato', name: 'Tomate italiano', unit: 'kg', stock: 5.2, min: 6, trend: -8, category: 'Hortifruti' },
  { id: 'chickpea', name: 'Grão-de-bico', unit: 'kg', stock: 8.4, min: 4, trend: 3, category: 'Secos' },
  { id: 'potato', name: 'Batata asterix', unit: 'kg', stock: 16, min: 8, trend: 16, category: 'Hortifruti' },
  { id: 'pumpkin', name: 'Abóbora cabotiá', unit: 'kg', stock: 11, min: 4, trend: 6, category: 'Hortifruti' },
  { id: 'oil', name: 'Azeite extravirgem', unit: 'L', stock: 3.4, min: 2, trend: -2, category: 'Despensa' },
  { id: 'leaves', name: 'Mix de folhas', unit: 'kg', stock: 2.1, min: 3, trend: -14, category: 'Hortifruti' },
];

export const dishes: Dish[] = [
  { id: 'citrus-chicken', name: 'Frango cítrico', description: 'Peito grelhado, molho de limão e arroz de ervas.', category: 'Prato principal', price: 28.5, accent: 'from-[#FFE4C7] to-[#F4B56E]', ingredients: [{ ingredientId: 'chicken', quantity: 0.18 }, { ingredientId: 'rice', quantity: 0.09 }, { ingredientId: 'oil', quantity: 0.008 }] },
  { id: 'med-bowl', name: 'Bowl mediterrâneo', description: 'Grão-de-bico, folhas, tomate e azeite de ervas.', category: 'Vegetariano', price: 24, accent: 'from-[#FFF0C9] to-[#DCC879]', ingredients: [{ ingredientId: 'chickpea', quantity: 0.12 }, { ingredientId: 'leaves', quantity: 0.045 }, { ingredientId: 'tomato', quantity: 0.06 }] },
  { id: 'pumpkin-gnocchi', name: 'Nhoque de abóbora', description: 'Massa de abóbora, manteiga de sálvia e parmesão.', category: 'Especial da casa', price: 26.5, accent: 'from-[#FFD9C8] to-[#E99675]', ingredients: [{ ingredientId: 'pumpkin', quantity: 0.22 }, { ingredientId: 'potato', quantity: 0.1 }, { ingredientId: 'oil', quantity: 0.01 }] },
  { id: 'season-salad', name: 'Salada de estação', description: 'Folhas, tomate italiano e vinagrete cítrico.', category: 'Leve', price: 18.5, accent: 'from-[#FFF1DC] to-[#E7C5A0]', ingredients: [{ ingredientId: 'leaves', quantity: 0.08 }, { ingredientId: 'tomato', quantity: 0.06 }] },
];

export const initialMenu: MenuDay[] = [
  { key: 'mon', label: 'Segunda', date: '21 out', iso: '2026-10-21', target: 4200, revenue: 3380, note: 'Recebimento de hortifruti às 08h.', special: '', dishIds: ['citrus-chicken', 'med-bowl', 'pumpkin-gnocchi'] },
  { key: 'tue', label: 'Terça', date: '22 out', iso: '2026-10-22', target: 4200, revenue: 3790, note: 'Conferir mise en place do almoço.', special: '', dishIds: ['citrus-chicken', 'med-bowl', 'season-salad'] },
  { key: 'wed', label: 'Quarta', date: '23 out', iso: '2026-10-23', target: 4200, revenue: 0, note: 'Especial vegetariano em destaque.', special: 'Nhoque de abóbora', dishIds: ['citrus-chicken', 'pumpkin-gnocchi', 'season-salad'] },
  { key: 'thu', label: 'Quinta', date: '24 out', iso: '2026-10-24', target: 4200, revenue: 0, note: 'Revisar porções do frango cítrico.', special: '', dishIds: ['citrus-chicken', 'med-bowl', 'pumpkin-gnocchi'] },
  { key: 'fri', label: 'Sexta', date: '25 out', iso: '2026-10-25', target: 4200, revenue: 0, note: 'Serviço estendido até 15h.', special: '', dishIds: ['citrus-chicken', 'med-bowl', 'season-salad'] },
  { key: 'sat', label: 'Sábado', date: '26 out', iso: '2026-10-26', target: 1800, revenue: 0, note: 'Brunch da equipe.', special: '', dishIds: ['med-bowl', 'pumpkin-gnocchi'] },
  { key: 'sun', label: 'Domingo', date: '27 out', iso: '2026-10-27', target: 1800, revenue: 0, note: 'Fechamento e inventário.', special: '', dishIds: ['citrus-chicken', 'season-salad'] },
];

export const monthlyRows = [
  { day: '01 out', service: 'Almoço', sales: 122, revenue: 3280, consumption: '7,4 kg', status: 'Fechado' },
  { day: '02 out', service: 'Almoço', sales: 146, revenue: 3890, consumption: '8,2 kg', status: 'Fechado' },
  { day: '03 out', service: 'Almoço + jantar', sales: 188, revenue: 5120, consumption: '11,5 kg', status: 'Fechado' },
  { day: '04 out', service: 'Almoço', sales: 134, revenue: 3660, consumption: '7,9 kg', status: 'Fechado' },
  { day: '05 out', service: 'Almoço', sales: 158, revenue: 4280, consumption: '9,1 kg', status: 'Fechado' },
  { day: '06 out', service: 'Almoço + jantar', sales: 211, revenue: 5740, consumption: '12,7 kg', status: 'Fechado' },
];
