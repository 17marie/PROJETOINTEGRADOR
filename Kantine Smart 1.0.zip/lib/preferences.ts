export const defaultPreferences = {
  brandName: 'Kantine Smart',
  menuTitle: 'Hoje na cozinha',
  menuSubtitle: 'Feito para servir bem, sem desperdício.',
  showDescriptions: true,
  showPortions: true,
};

export type Preferences = typeof defaultPreferences;
