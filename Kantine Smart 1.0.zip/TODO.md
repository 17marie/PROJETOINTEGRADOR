# Entregas Nourish

## Dashboard operacional

- [ ] Exibir uma visão geral rápida com faturamento, vendas, desperdício estimado, alertas de estoque, pratos esgotados e visão da semana.
- [ ] Permitir registrar uma venda a partir do dashboard; a venda deve dar baixa automática no estoque dos ingredientes correspondentes e recalcular a disponibilidade do prato.
- [ ] Manter navegação responsiva entre Dashboard, Estoque, Agenda, Cardápio, Relatórios e Personalizar.

## Autenticação de gestores

- [ ] Disponibilizar login e senha seguro para administradores/gerentes.
- [ ] Manter sessão HTTP-only e o cookie `webdev_app_session` compatível com Preview HTTPS (`SameSite=None; Secure`).
- [ ] Exibir credenciais de demonstração claramente para permitir avaliação local do protótipo.

## Estoque e ficha técnica

- [ ] CRUD de ingredientes com unidade, estoque atual e estoque mínimo.
- [ ] Exibir alertas para itens abaixo do mínimo e permitir ajuste rápido do estoque.
- [ ] Exibir a ficha técnica de cada prato e o ingrediente gargalo.
- [ ] Calcular `Porções Possíveis = Math.floor(Estoque Atual do Ingrediente / Quantidade Necessária)` e usar o menor resultado entre ingredientes essenciais.
- [ ] Mudar automaticamente o status para `Esgotado` quando qualquer ingrediente não permitir uma porção e retornar para `Disponível` após reabastecimento.

## Agenda semanal

- [ ] Exibir grade interativa de segunda a domingo para planejar pratos, registrar notas, metas e pratos especiais.
- [ ] Permitir editar um dia por meio de painel de edição rápida e salvar notas operacionais.
- [ ] Disponibilizar “Fechar semana” para consolidar os dados no balanço mensal.

## Cardápio dinâmico

- [ ] Disponibilizar CRUD de pratos e categorias.
- [ ] Exibir nome, descrição, categoria, preço, porções possíveis e status `Disponível`/`Esgotado`.
- [ ] Atualizar o status automaticamente com base no estoque da ficha técnica.
- [ ] Permitir customizar marca, mensagem e informações exibidas no cardápio.

## Relatórios e dados

- [ ] Consolidar vendas, faturamento e histórico de consumo de estoque no resumo mensal.
- [ ] Exibir dados operacionais diários e semanais em tabela.
- [ ] Permitir exportar os dados para CSV.

## Entrega técnica

- [ ] Usar Next.js App Router + TypeScript + Tailwind CSS.
- [ ] Manter `prisma/schema.prisma`, migração e `prisma/seed.ts` com os modelos solicitados.
- [ ] Disponibilizar route handlers para ingredientes, pratos, disponibilidade, agenda, vendas e resumo mensal.
- [ ] Servir `GET /manus-routes.json` com todas as rotas navegáveis.
- [ ] Rodar verificação de tipos e build sem erros; iniciar o Preview na porta configurada.
