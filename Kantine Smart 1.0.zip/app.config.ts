export default {
  logoUrl: "https://images.unsplash.com/photo-1495195134817-aeb325a55b65?auto=format&fit=crop&w=64&q=80",
};
