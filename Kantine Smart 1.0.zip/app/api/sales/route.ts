import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { calculateAvailability } from '@/lib/availability';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const body = await request.json();
  const dishId = String(body.dishId);
  const quantity = Math.max(1, Number(body.quantity || 1));
  const dish = await prisma.dish.findUnique({ where: { id: dishId }, include: { dishIngredients: { include: { ingredient: true } } } });
  if (!dish) return NextResponse.json({ error: 'Prato não encontrado.' }, { status: 404 });
  const status = calculateAvailability(dish.dishIngredients);
  if (status.portions < quantity) return NextResponse.json({ error: 'Estoque insuficiente para esta venda.' }, { status: 409 });
  const sale = await prisma.$transaction(async (transaction) => {
    for (const entry of dish.dishIngredients) {
      const quantityUsed = entry.quantityRequired * quantity;
      await transaction.ingredient.update({ where: { id: entry.ingredientId }, data: { currentStock: { decrement: quantityUsed } } });
      await transaction.stockMovement.create({ data: { ingredientId: entry.ingredientId, quantity: -quantityUsed, kind: 'VENDA', note: `${quantity}x ${dish.name}` } });
    }
    return transaction.sale.create({ data: { dishId, quantity, total: dish.price * quantity, channel: String(body.channel || 'BALCÃO') } });
  });
  return NextResponse.json(sale, { status: 201 });
}
