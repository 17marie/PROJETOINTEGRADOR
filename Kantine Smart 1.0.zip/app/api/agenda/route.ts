import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const agenda = await prisma.weeklyAgenda.findFirst({ orderBy: [{ year: 'desc' }, { weekNumber: 'desc' }], include: { dailyMenus: { include: { dishes: { include: { dish: true } } }, orderBy: { date: 'asc' } } } });
  return NextResponse.json(agenda);
}

export async function PATCH(request: Request) {
  const body = await request.json();
  if (body.action === 'close') {
    const agenda = await prisma.weeklyAgenda.update({ where: { id: String(body.agendaId) }, data: { isClosed: true }, include: { dailyMenus: true } });
    const month = new Date().getMonth() + 1;
    const year = new Date().getFullYear();
    const totalRevenue = agenda.dailyMenus.reduce((sum, day) => sum + day.dailyRevenue, 0);
    const summary = await prisma.monthlySummary.upsert({ where: { month_year: { month, year } }, create: { month, year, totalRevenue, totalSales: 0, wasteEstimate: 0, stockReportJson: JSON.stringify({ closedAgendaId: agenda.id }) }, update: { totalRevenue: { increment: totalRevenue }, stockReportJson: JSON.stringify({ closedAgendaId: agenda.id }) } });
    return NextResponse.json({ agenda, summary });
  }
  const day = await prisma.dailyMenu.update({ where: { id: String(body.id) }, data: { notes: body.notes, dailyTarget: body.dailyTarget === undefined ? undefined : Number(body.dailyTarget), specialDish: body.specialDish } });
  return NextResponse.json(day);
}
