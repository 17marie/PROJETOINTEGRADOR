import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const ingredients = await prisma.ingredient.findMany({ orderBy: { name: 'asc' } });
  return NextResponse.json(ingredients);
}

export async function POST(request: Request) {
  const body = await request.json();
  const ingredient = await prisma.ingredient.create({ data: { name: String(body.name), unit: String(body.unit || 'kg'), currentStock: Number(body.currentStock || 0), minAlert: Number(body.minAlert || 0) } });
  return NextResponse.json(ingredient, { status: 201 });
}
