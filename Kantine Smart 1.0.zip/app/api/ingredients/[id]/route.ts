import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

type Context = { params: { id: string } };

export async function PATCH(request: Request, { params }: Context) {
  const body = await request.json();
  const ingredient = await prisma.ingredient.update({ where: { id: params.id }, data: { name: body.name, unit: body.unit, currentStock: body.currentStock === undefined ? undefined : Number(body.currentStock), minAlert: body.minAlert === undefined ? undefined : Number(body.minAlert) } });
  return NextResponse.json(ingredient);
}

export async function DELETE(_request: Request, { params }: Context) {
  await prisma.ingredient.delete({ where: { id: params.id } });
  return new NextResponse(null, { status: 204 });
}
