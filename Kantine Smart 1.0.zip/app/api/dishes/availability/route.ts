import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { calculateAvailability } from '@/lib/availability';

export const dynamic = 'force-dynamic';

export async function GET() {
  const dishes = await prisma.dish.findMany({ include: { dishIngredients: { include: { ingredient: true } } }, orderBy: { name: 'asc' } });
  const result = dishes.map((dish) => { const status = calculateAvailability(dish.dishIngredients); return { id: dish.id, name: dish.name, isAvailable: status.isAvailable, portions: status.portions, bottleneck: status.bottleneck?.ingredient.name ?? null }; });
  return NextResponse.json(result);
}
