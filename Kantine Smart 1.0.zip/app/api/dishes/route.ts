import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const dishes = await prisma.dish.findMany({ include: { dishIngredients: { include: { ingredient: true } } }, orderBy: { name: 'asc' } });
  return NextResponse.json(dishes);
}

export async function POST(request: Request) {
  const body = await request.json();
  const dish = await prisma.dish.create({ data: { name: String(body.name), description: body.description ? String(body.description) : undefined, price: Number(body.price || 0), category: String(body.category || 'Prato principal'), dishIngredients: { create: (body.ingredients || []).map((item: { ingredientId: string; quantityRequired: number }) => ({ ingredientId: item.ingredientId, quantityRequired: Number(item.quantityRequired) })) } }, include: { dishIngredients: true } });
  return NextResponse.json(dish, { status: 201 });
}

export async function PATCH(request: Request) {
  const body = await request.json();
  const dish = await prisma.dish.update({ where: { id: String(body.id) }, data: { name: body.name, description: body.description, price: body.price === undefined ? undefined : Number(body.price), category: body.category, isAvailable: body.isAvailable } });
  return NextResponse.json(dish);
}

export async function DELETE(request: Request) {
  const body = await request.json();
  await prisma.dish.delete({ where: { id: String(body.id) } });
  return new NextResponse(null, { status: 204 });
}
