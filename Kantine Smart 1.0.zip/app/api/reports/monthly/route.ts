import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const url = new URL(request.url);
  const month = Number(url.searchParams.get('month') || new Date().getMonth() + 1);
  const year = Number(url.searchParams.get('year') || new Date().getFullYear());
  const [summary, sales, ingredients] = await Promise.all([prisma.monthlySummary.findUnique({ where: { month_year: { month, year } } }), prisma.sale.findMany({ where: { soldAt: { gte: new Date(year, month - 1, 1), lt: new Date(year, month, 1) } }, include: { dish: true }, orderBy: { soldAt: 'asc' } }), prisma.ingredient.findMany({ orderBy: { name: 'asc' } })]);
  return NextResponse.json({ summary, sales, ingredients });
}
