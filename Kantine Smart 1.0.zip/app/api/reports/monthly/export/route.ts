import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export async function GET() {
  const sales = await prisma.sale.findMany({ include: { dish: true }, orderBy: { soldAt: 'asc' } });
  const header = 'data,prato,quantidade,faturamento,canal';
  const rows = sales.map((sale) => [sale.soldAt.toISOString().slice(0, 10), sale.dish.name, sale.quantity, sale.total.toFixed(2), sale.channel].map((value) => `"${String(value).replaceAll('"', '""')}"`).join(','));
  return new Response([header, ...rows].join('\n'), { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="nourish-relatorio.csv"' } });
}
