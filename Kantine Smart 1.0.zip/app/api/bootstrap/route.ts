import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const accents = [
  'from-[#FFE4C7] to-[#F4B56E]',
  'from-[#FFF0C9] to-[#DCC879]',
  'from-[#FFD9C8] to-[#E99675]',
  'from-[#FFF1DC] to-[#E7C5A0]',
];

export async function GET() {
  const agenda = await prisma.weeklyAgenda.findFirst({
    orderBy: [{ year: 'desc' }, { weekNumber: 'desc' }],
    include: {
      dailyMenus: {
        include: { dishes: { include: { dish: true } } },
        orderBy: { date: 'asc' },
      },
    },
  });
  const [ingredients, dishes] = await Promise.all([
    prisma.ingredient.findMany({ orderBy: { name: 'asc' } }),
    prisma.dish.findMany({ include: { dishIngredients: true }, orderBy: { createdAt: 'asc' } }),
  ]);
  const categories: Record<string, string> = {
    'Peito de frango': 'Proteína',
    'Arroz agulhinha': 'Secos',
    'Tomate italiano': 'Hortifruti',
    'Grão-de-bico': 'Secos',
    'Batata asterix': 'Hortifruti',
    'Abóbora cabotiá': 'Hortifruti',
    'Azeite extravirgem': 'Despensa',
    'Mix de folhas': 'Hortifruti',
  };
  const weekdayKeys = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  const menu = (agenda?.dailyMenus || []).map((day, index) => ({
    id: day.id,
    key: weekdayKeys[index] || String(index),
    label: day.dayOfWeek,
    date: new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' }).format(day.date).replace('.', ''),
    iso: day.date.toISOString().slice(0, 10),
    target: day.dailyTarget,
    revenue: day.dailyRevenue,
    note: day.notes || '',
    special: day.specialDish || '',
    dishIds: day.dishes.sort((a, b) => a.position - b.position).map((item) => item.dishId),
  }));
  return NextResponse.json({
    agendaId: agenda?.id || null,
    closed: Boolean(agenda?.isClosed),
    ingredients: ingredients.map((item) => ({
      id: item.id,
      name: item.name,
      unit: item.unit,
      stock: item.currentStock,
      min: item.minAlert,
      trend: item.currentStock <= item.minAlert ? -8 : 6,
      category: categories[item.name] || 'Despensa',
    })),
    dishes: dishes.map((dish, index) => ({
      id: dish.id,
      name: dish.name,
      description: dish.description || '',
      category: dish.category,
      price: dish.price,
      accent: accents[index % accents.length],
      ingredients: dish.dishIngredients.map((item) => ({ ingredientId: item.ingredientId, quantity: item.quantityRequired })),
    })),
    menu,
  });
}
