import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { createSessionToken, SESSION_COOKIE } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  let user;
  try {
    user = await prisma.user.findUnique({ where: { email } });
  } catch (error) {
    console.error('Login database error:', error);
    return NextResponse.json({ error: 'O serviço de acesso está temporariamente indisponível.' }, { status: 503 });
  }
  if (!user || !(await bcrypt.compare(password, user.password))) return NextResponse.json({ error: 'E-mail ou senha inválidos.' }, { status: 401 });
  const token = createSessionToken({ id: user.id, name: user.name, email: user.email, role: user.role });
  const response = NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  const origin = request.headers.get('origin') || '';
  const referer = request.headers.get('referer') || '';
  const publicHttps = process.env.NODE_ENV === 'production'
    || request.headers.get('x-forwarded-proto') === 'https'
    || origin.startsWith('https://')
    || referer.startsWith('https://');
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: publicHttps,
    sameSite: publicHttps ? 'none' : 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 30,
  });
  return response;
}
