import NourishApp from '@/components/nourish-app';

export default function CustomizePage() {
  return <NourishApp section="personalizar" />;
}
