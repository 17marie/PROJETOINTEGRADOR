import NourishApp from '@/components/nourish-app';

export default function HomePage() {
  return <NourishApp section="dashboard" />;
}
