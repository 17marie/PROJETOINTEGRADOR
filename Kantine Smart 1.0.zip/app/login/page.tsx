import LoginScreen from '@/components/login-screen';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Entrar — Kantine Smart',
  description: 'Acesso seguro ao painel de gestão da Kantine Smart.',
};

export default function LoginPage() {
  return <LoginScreen />;
}
