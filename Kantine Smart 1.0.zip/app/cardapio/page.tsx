import NourishApp from '@/components/nourish-app';

export default function MenuPage() {
  return <NourishApp section="cardapio" />;
}
