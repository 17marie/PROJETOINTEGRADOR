import NourishApp from '@/components/nourish-app';

export default function AgendaPage() {
  return <NourishApp section="agenda" />;
}
