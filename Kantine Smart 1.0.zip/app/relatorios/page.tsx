import NourishApp from '@/components/nourish-app';

export default function ReportsPage() {
  return <NourishApp section="relatorios" />;
}
