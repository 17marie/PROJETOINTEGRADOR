import NourishApp from '@/components/nourish-app';

export default function StockPage() {
  return <NourishApp section="estoque" />;
}
