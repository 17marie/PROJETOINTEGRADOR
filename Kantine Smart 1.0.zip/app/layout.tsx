import type { Metadata } from 'next';
import { DM_Serif_Display, Manrope } from 'next/font/google';
import './globals.css';

const manrope = Manrope({ subsets: ['latin'], variable: '--font-manrope', display: 'swap' });
const dmSerif = DM_Serif_Display({ weight: '400', subsets: ['latin'], variable: '--font-dm-serif', display: 'swap' });

export const metadata: Metadata = {
  title: 'Kantine Smart — Gestão inteligente de cozinha',
  description: 'Planejamento de cardápio e estoque para cozinhas que querem servir melhor.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR" suppressHydrationWarning><body className={`${manrope.variable} ${dmSerif.variable}`}>{children}</body></html>;
}
