import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  await prisma.sale.deleteMany();
  await prisma.stockMovement.deleteMany();
  await prisma.dailyMenuDish.deleteMany();
  await prisma.dailyMenu.deleteMany();
  await prisma.weeklyAgenda.deleteMany();
  await prisma.dishIngredient.deleteMany();
  await prisma.dish.deleteMany();
  await prisma.ingredient.deleteMany();
  await prisma.monthlySummary.deleteMany();
  await prisma.user.deleteMany();

  const password = await bcrypt.hash('Chef1223', 10);
  await prisma.user.create({
    data: { email: 'admin@kantine.test', name: 'Administrador', password, role: 'ADMIN' },
  });

  const ingredientData = [
    { name: 'Peito de frango', unit: 'kg', currentStock: 18.5, minAlert: 8 },
    { name: 'Arroz agulhinha', unit: 'kg', currentStock: 24, minAlert: 12 },
    { name: 'Tomate italiano', unit: 'kg', currentStock: 5.2, minAlert: 6 },
    { name: 'Grão-de-bico', unit: 'kg', currentStock: 8.4, minAlert: 4 },
    { name: 'Batata asterix', unit: 'kg', currentStock: 16, minAlert: 8 },
    { name: 'Abóbora cabotiá', unit: 'kg', currentStock: 11, minAlert: 4 },
    { name: 'Azeite extravirgem', unit: 'L', currentStock: 3.4, minAlert: 2 },
    { name: 'Mix de folhas', unit: 'kg', currentStock: 2.1, minAlert: 3 },
  ];
  const ingredients = await Promise.all(ingredientData.map((data) => prisma.ingredient.create({ data })));
  const byName = Object.fromEntries(ingredients.map((item) => [item.name, item]));

  const dishes = await Promise.all([
    prisma.dish.create({
      data: {
        name: 'Frango cítrico', description: 'Peito grelhado, molho de limão e arroz de ervas.', price: 28.5, category: 'Prato principal', isAvailable: true,
        dishIngredients: { create: [
          { ingredientId: byName['Peito de frango'].id, quantityRequired: 0.18 },
          { ingredientId: byName['Arroz agulhinha'].id, quantityRequired: 0.09 },
          { ingredientId: byName['Azeite extravirgem'].id, quantityRequired: 0.008 },
        ] },
      },
    }),
    prisma.dish.create({
      data: {
        name: 'Bowl mediterrâneo', description: 'Grão-de-bico, folhas, tomate e azeite de ervas.', price: 24, category: 'Vegetariano', isAvailable: true,
        dishIngredients: { create: [
          { ingredientId: byName['Grão-de-bico'].id, quantityRequired: 0.12 },
          { ingredientId: byName['Mix de folhas'].id, quantityRequired: 0.045 },
          { ingredientId: byName['Tomate italiano'].id, quantityRequired: 0.06 },
        ] },
      },
    }),
    prisma.dish.create({
      data: {
        name: 'Nhoque de abóbora', description: 'Massa de abóbora, manteiga de sálvia e parmesão.', price: 26.5, category: 'Especial da casa', isAvailable: true,
        dishIngredients: { create: [
          { ingredientId: byName['Abóbora cabotiá'].id, quantityRequired: 0.22 },
          { ingredientId: byName['Batata asterix'].id, quantityRequired: 0.1 },
          { ingredientId: byName['Azeite extravirgem'].id, quantityRequired: 0.01 },
        ] },
      },
    }),
    prisma.dish.create({
      data: {
        name: 'Salada de estação', description: 'Folhas, tomate italiano e vinagrete cítrico.', price: 18.5, category: 'Leve', isAvailable: false,
        dishIngredients: { create: [
          { ingredientId: byName['Mix de folhas'].id, quantityRequired: 0.08 },
          { ingredientId: byName['Tomate italiano'].id, quantityRequired: 0.06 },
        ] },
      },
    }),
  ]);

  const now = new Date();
  const monday = new Date(now);
  const day = monday.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  monday.setDate(monday.getDate() + diff);
  monday.setHours(12, 0, 0, 0);
  const weekNumber = Math.ceil((((monday.getTime() - new Date(monday.getFullYear(), 0, 1).getTime()) / 86400000) + 1) / 7);
  const agenda = await prisma.weeklyAgenda.create({ data: { weekNumber, year: monday.getFullYear() } });
  const days = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
  const dayNotes = ['Recebimento de hortifruti às 08h.', 'Conferir mise en place do almoço.', 'Especial vegetariano em destaque.', 'Revisar porções do frango cítrico.', 'Serviço estendido até 15h.', 'Brunch da equipe.', 'Fechamento e inventário.'];
  for (let index = 0; index < days.length; index += 1) {
    const date = new Date(monday);
    date.setDate(monday.getDate() + index);
    await prisma.dailyMenu.create({
      data: {
        agendaId: agenda.id,
        date,
        dayOfWeek: days[index],
        notes: dayNotes[index],
        dailyTarget: index < 5 ? 4200 : 1800,
        dailyRevenue: index < 3 ? 3380 + index * 410 : 0,
        specialDish: index === 2 ? 'Nhoque de abóbora' : undefined,
        dishes: { create: [{ dishId: dishes[0].id, position: 0 }, { dishId: dishes[1].id, position: 1 }, { dishId: dishes[2].id, position: 2 }] },
      },
    });
  }
  await prisma.monthlySummary.create({
    data: { month: now.getMonth() + 1, year: now.getFullYear(), totalRevenue: 38460, totalSales: 1428, wasteEstimate: 3.8, stockReportJson: JSON.stringify({ alerts: 2, bestDish: 'Frango cítrico' }) },
  });
  await prisma.stockMovement.createMany({ data: ingredients.slice(0, 4).map((item) => ({ ingredientId: item.id, quantity: item.currentStock, kind: 'ENTRADA', note: 'Carga inicial' })) });
  await prisma.sale.createMany({ data: [{ dishId: dishes[0].id, quantity: 24, total: 684 }, { dishId: dishes[1].id, quantity: 18, total: 432 }, { dishId: dishes[2].id, quantity: 12, total: 318 }] });
}

main().finally(async () => prisma.$disconnect());
