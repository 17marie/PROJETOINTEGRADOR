# Plano de implementação — Nourish

## Objetivo

Construir um protótipo funcional de gestão de restaurantes, cantinas e refeitórios que transforme estoque e fichas técnicas em decisões operacionais: pratos disponíveis, capacidade de porções, cardápio semanal e consolidação mensal.

A entrega terá uma experiência navegável e responsiva, com dados de demonstração e fluxos que podem ser testados localmente.

## Decisões de arquitetura

- **Framework:** Next.js com App Router e TypeScript.
- **Interface:** Tailwind CSS, componentes reutilizáveis e suporte de tema claro/escuro.
- **Dados:** Prisma ORM e SQLite local, com `schema.prisma`, migração e `prisma/seed.ts`.
- **Autenticação:** login por e-mail e senha; senhas do usuário de demonstração serão armazenadas com hash bcrypt e a sessão será HTTP-only. Para o Preview HTTPS, o cookie seguirá `SameSite=None; Secure`.
- **API:** Route Handlers do Next.js para ingredientes, pratos, disponibilidade, agenda, fechamento e resumo mensal.
- **Regra central:** `porções possíveis = floor(estoque atual / quantidade exigida)`. A menor capacidade dentre os ingredientes da ficha técnica define o gargalo do prato. Com zero porções, o prato fica esgotado.
- **Vendas:** uma venda do protótipo baixa proporcionalmente os ingredientes da ficha técnica e recalcula o status do prato.
- **Limite de persistência:** SQLite atende ao requisito para desenvolvimento/local e ao protótipo. Em publicação num contêiner, o arquivo local não é durável; a migração prevista é trocar `DATABASE_URL` por PostgreSQL/Supabase sem alterar o modelo de domínio.

## Escopo de páginas e fluxos

1. **Login (`/login`)** — autenticação de gerente/administrador; credenciais de teste estarão visíveis na própria tela para avaliação do protótipo.
2. **Dashboard (`/`)** — leitura rápida da operação: faturamento, vendas, desperdício estimado, alertas de estoque, pratos esgotados, visão da semana e ação para registrar venda.
3. **Estoque (`/estoque`)** — tabela de ingredientes, alerta de mínimo, ajuste de estoque, painel de ficha técnica e cálculo do gargalo por prato.
4. **Agenda (`/agenda`)** — faixa semanal de segunda a domingo, seleção de dia, pratos planejados, notas, meta diária e ação “Fechar semana”. Um painel/modal de edição rápida permite salvar as informações de cada dia.
5. **Cardápio (`/cardapio`)** — versão voltada à equipe/cliente, com preço, categoria, porções possíveis e sinalização automática de `Disponível`/`Esgotado`.
6. **Relatórios (`/relatorios`)** — resumo mensal, totais operacionais e tabela exportável em CSV dos dados diários/semanais.
7. **Customização (`/personalizar`)** — controles de marca, mensagem e itens que aparecem no cardápio dinâmico; as preferências ficam persistidas localmente no protótipo.

## Modelo de dados

O `schema.prisma` conterá as entidades requisitadas:

- `User`, `Ingredient`, `Dish`, `DishIngredient`
- `WeeklyAgenda`, `DailyMenu`, `MonthlySummary`

Para tornar os fluxos completos, o modelo incluirá relações para pratos planejados no dia, uma meta diária e registros simples de venda. As extensões preservam as entidades e os atributos obrigatórios da solicitação.

## Estrutura de projeto

```text
app/
  (auth)/login/                 Tela de acesso
  (dashboard)/                  Páginas protegidas do produto
  api/                          APIs de estoque, pratos, agenda, vendas e relatórios
  layout.tsx                    Metadados, fontes e tema
  globals.css                   Tokens visuais e estilos globais
components/
  layout/                       Sidebar, cabeçalho e navegação móvel
  dashboard/                    Cartões e indicadores operacionais
  estoque/ agenda/ cardapio/    Componentes específicos de cada módulo
  ui/                           Componentes reutilizáveis
lib/
  availability.ts               Cálculo do ingrediente gargalo e status do prato
  auth.ts                       Sessão e verificação de credenciais
  prisma.ts                     Cliente Prisma singleton
  format.ts                     Formatação de moeda e datas
prisma/
  schema.prisma                 Modelo relacional
  seed.ts                       Restaurante e dados de demonstração
public/
  manus-routes.json             Manifesto das rotas navegáveis
plan.md                         Este plano
TODO.md                         Resultados e critérios de aceite
```

## Direção visual

### Explorações consideradas

- **Brutalismo de cozinha industrial** (7%): operacional e de alto contraste, mas excessivamente duro para uso diário.
- **Hospitalidade editorial mediterrânea** (5%): calor humano e textura, porém menos adequada para dados em tempo real.
- **Calm Operations / Soft Utility** (8%): a direção escolhida, combinando precisão operacional com serenidade de uma cozinha organizada.

### Direção escolhida: Calm Operations / Soft Utility

- **Movimento de design:** software de operações contemporâneo inspirado em etiquetas de despensa, cadernos de chef e sistemas de sinalização discretos.
- **Princípios:** clareza antes de decoração; alertas acionáveis; respiro generoso; dados legíveis à distância.
- **Filosofia de cor:** uma base grafite-esverdeada comunica controle e foco; superfícies marfim reduzem fadiga; verde sálvia confirma disponibilidade; coral queimado sinaliza risco ou esgotamento sem agressividade.
- **Paradigma de layout:** uma barra lateral escura atua como “espinha da cozinha”; cada tela possui uma faixa de contexto no topo e uma tela operacional contínua, com cartões apenas para decisões e não para todo conteúdo.
- **Elementos de assinatura:** marca em forma de prato/círculo com folha; chips com ponto de status; divisórias pontilhadas que sugerem etiquetas de produção.
- **Interação:** ajustes, notas e vendas usam painéis locais e confirmação de resultado para reduzir trocas de contexto. Cores nunca serão o único indicador de status.
- **Animação:** transições de 160–220 ms, pequenas elevações de cartões e preenchimento suave em indicadores; respeitar `prefers-reduced-motion`.
- **Tipografia:** `Manrope` para interface e números, com `DM Serif Display` pontual nos títulos de contexto e no cardápio público.
- **Essência da marca:** “Nourish organiza o que a cozinha já sabe, para que cada serviço comece com certeza.” Personalidade: serena, competente, próxima.
- **Voz:** direta e útil. Exemplos: “O frango define a capacidade de hoje.” e “Feche a semana quando os números estiverem no prato.”
- **Logotipo:** símbolo circular que combina prato e folha no negativo, seguido de wordmark geométrico; a cor proprietária é o verde `Basil`.

## Fluxo de execução

1. Configurar diagnóstico TypeScript e scaffolding Next.js/Tailwind.
2. Implementar Prisma, migração e seed com ingredientes, pratos, fichas técnicas, agenda e dados financeiros.
3. Criar a camada de autenticação e APIs com as regras de disponibilidade/venda.
4. Implementar todas as telas e interações principais usando os dados persistidos.
5. Rodar seed, verificação de tipos, build e revisão técnica; iniciar Preview para inspeção visual.
6. Preparar Dockerfile e rota de saúde para uma futura publicação server-side.
